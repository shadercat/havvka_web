var express = require("express");
var router = express.Router();
const Set = require("../models/Set")

router.get("/:user_id",(req, res) => {
  Set.findAll({
    where: {
      user_id: req.params.user_id
    }
  })
  .then(orders => {
    res.json(orders)
  })
  .catch(err => {
    res.send("error: " + err)
  })
})

router.post("/create", (req, res) => {
  const setData = {
    set_name: req.query.name,
    user_id: req.query.user_id
  }

  Set.create(setData)
  .then(set => {
      res.json({status: 'created'})
  })
  .catch(err =>
      res.send("error: " + err)
  )
})

module.exports = router;
